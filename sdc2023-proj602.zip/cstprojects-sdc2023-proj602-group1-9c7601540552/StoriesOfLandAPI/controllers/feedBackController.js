const Feedback = require('../db/models/Feedback');
const Plant = require('../db/models/Plants');

/**
 * create new feedback in the database.
 * @param {Object} req - The HTTP request object.
 * @param {Object} res - The HTTP response object.
 * @returns null
 */
const createFeedback = async (req, res) => {

    try {
      // Extract the necessary data from the request body
      const { name, email ,feedback ,plantId} = req.body;
        
   
    // Create a new instance of the feedback model with the extracted data
    const feed_back = new Feedback({
        name,email,feedback,
        read: "no",plantId
        
      });

      // Save the plant object to MongoDB
      await feed_back.save();
      
      return res.status(200).json({ success: true, message: 'Feedback submitted' });
    } catch (error) {
      // Handle any errors that occur during the process
      return res.status(400).json({ success: false, error: error.message });
    }
  }

  /**
   * This code defines a function for retrieving the count of unread feedback.
   * @param {Object} req - The HTTP request object.
   * @param {Object} res - The HTTP response object.
   * @returns count of the unread feedback
   */
  const getFeedbackCount  = async (req, res) => {
    try {
      // Find the count of feedback where read = "no"
      const count = await Feedback.countDocuments({ read: "no" });
  
      return res.status(200).json({ success: true, count });
    } catch (error) {
      //error handling code
      return res.status(400).json({ success: false, error: error.message });
    }
  };


/**
 * 
 * @param {Object} req - The HTTP request object.
 * @param {Object} res - The HTTP response object.
 * @returns {Object} The HTTP response containing the feedback entries or an error message.
  
 */

  const getAllFeedback = async (req, res) => {
    try {
      
      // Retrieve all feedback entries from the database
      const feedback = await Feedback.find();
  
      // Check if any feedback entries exist
      if (!feedback.length) {
        return res.status(404).json({ success: false, error: "No Feedback found." });
      }
  
      // Create an array to store the modified feedback entries
      const modifiedFeedback = [];
  
      // Iterate through each feedback entry
      for (const entry of feedback) {
        // Retrieve the corresponding plant from the "plants" collection based on the feedback ID
        const plant = await Plant.findOne({ _id: entry.plantId });
        
        
        // Create a new object with the feedback data and plant name
        const modifiedEntry = {
          _id: entry._id,
          name:entry.name,
          email:entry.email,
          feedback: entry.feedback,
          read :entry.read,
          plantName: plant ? plant.plantName : "Unknown", // Attach the plant name to the response or set it as "Unknown" if not found
         
        };
  
        // Add the modified entry to the array
        modifiedFeedback.push(modifiedEntry);
        
      }
  
      // Return the modified feedback entries and corresponding plant names in the HTTP response
      return res.status(200).json({ success: true, data: modifiedFeedback });
    } catch (err) {
      return res.status(400).json({ success: false, error: err.message });
    }
  };
  

  /**
 * Updates the "read" field of a feedback entry to "yes".
 *
 * @param {Object} req - The HTTP request object.
 * @param {Object} res - The HTTP response object.
 * @returns {Object} The HTTP response containing the updated feedback entry or an error message.
 */  
  const updateReadFeedback = async (req, res) => {
    try {

      // Extract the feedback ID from the request parameters
      const id = req.params.id;        
      
      // Find the feedback by ID and update the read field to "yes"
      const updatedFeedback = await Feedback.findByIdAndUpdate(
        id,
        { read: 'yes' }
        
      );  
      // Check if the feedback was found and updated
      if (!updatedFeedback) {
        return res
          .status(404)
          .json({ success: false, error: 'Feedback not found' });
      }
      // Return the updated feedback entry in the HTTP response
      return res.json({ success: true, data: updatedFeedback });
    } catch (error) {
      // Handle any errors that occur during the process
      return res.status(400).json({ success: false, error: error.message });
    }
  };
  
/**
 * Deletes a feedback entry by ID.
 *
 * @param {Object} req - The HTTP request object.
 * @param {Object} res - The HTTP response object.
 * @returns {Object} The HTTP response containing a success message or an error message.
 */
const deleteFeedBack = async (req, res)=>{
   // Extract the feedback ID from the request parameters
   const id = req.params.id;

   // Find and remove the feedback entry by ID
  Feedback.findByIdAndRemove(id).then((feedback)=>{
    // Return a success message and the deleted feedback entry in the HTTP response
      return res.status(200).json({success: true, message: "Feedback deleted", data: feedback});
  }).catch((err)=>{
    // Handle any errors that occur during the process
      return res.status(400).json({sucess: false, error: err});
  });
};


  module.exports = {
   createFeedback,
    getAllFeedback,
   deleteFeedBack,
   getFeedbackCount,
   updateReadFeedback


};
  
  
  