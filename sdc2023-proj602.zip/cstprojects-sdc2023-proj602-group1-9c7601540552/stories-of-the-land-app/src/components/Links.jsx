import {Link} from 'react-router-dom';
import React, {  useEffect ,useContext } from 'react';
import apiCalls from '../api';
import { FeedbackContext } from '../context/FeedbackContext';

/**
 * Returns component for navigation
 * @returns Creates link to navigate to routes
 */
const Links = () => {

    const { feedbackCount, updateFeedbackCount } = useContext(FeedbackContext);
    const userStatus = sessionStorage.getItem("userStatus");    
   
    useEffect(() => { 
        apiCalls.getFeedbackCount()
            .then((res) => {
                const count = res.data.count;
             
               updateFeedbackCount(count);
            })
            .catch(console.error);
    }, [updateFeedbackCount]);    
      
    return(
        <>
            <Link className="navbar-brand" to="/plant/list">Stories of the Land App</Link>
            <div className = 'navbar-nav me-auto'>
                <Link className="nav-link" to="/plant/list">Specimens</Link>
                <Link className="nav-link" to="/feedback/list">
        Feedback {feedbackCount > 0 && <span className="badge bg-danger">{feedbackCount}</span>}
      </Link>
                {(userStatus === "main") && <Link className="nav-link" to="/usermanagement">User Management</Link>}
            </div>
        </>
    );
};

export default Links;
