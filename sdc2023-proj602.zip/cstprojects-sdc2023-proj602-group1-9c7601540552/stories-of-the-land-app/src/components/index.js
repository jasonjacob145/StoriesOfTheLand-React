import NavBar from "./NavBar/NavBar";
import Specimen from "./Specimen/Specimen";
import UserInput from "./Form/UserInput";

export {NavBar, Specimen, UserInput}