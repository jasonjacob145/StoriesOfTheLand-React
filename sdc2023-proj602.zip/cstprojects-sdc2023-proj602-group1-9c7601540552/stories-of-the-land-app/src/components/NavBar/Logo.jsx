import SaskPolyLogo from '../../assets/logos/Saskatchewan_Polytechnic.png';
import SWFLogo from '../../assets/logos/SWF-Logo.png'
import PAGCLogo from '../../assets/logos/pagc-logo.png'

/**
 * Logo Image
 * @returns Image element
 */
const Logo = () => {
    return(
        <>
            <a href="https://saskpolytech.ca/">
                <img src={SaskPolyLogo}
                alt="SaskPolylogo"
                height="50"
                style={{ marginRight: '20px' , marginLeft: '10px' }}
                />
            </a>
            <a href="https://www.pagc.sk.ca/">
                <img src={PAGCLogo}
                alt="PAGCLogo"
                height="25"
                style={{ marginRight: '20px' , marginLeft: '10px' }}
                />
            </a>
            <a href="https://swf.sk.ca/">
                <img src={SWFLogo}
                height="50"
                style={{ marginRight: '20px', backgroundColor: 'white' }}          
                alt="SWFlogo"/>
            </a>
        </>
        
    );
};

export default Logo;
