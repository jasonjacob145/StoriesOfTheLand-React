import React, { useState ,useEffect ,useContext } from 'react';
import apiCalls from "../api";
import { useNavigate } from 'react-router-dom';
import { FeedbackContext } from '../context/FeedbackContext';
import styles from "./FeedbackList.module.css";
import { NavBar } from '../components';


const FeedbackList = () => {
  const { updateFeedbackCount } = useContext(FeedbackContext);
  const [feedbacks, setFeedbacks] = useState([]);
  const [modalState, setModalState] = useState(false);
  const [selectedFeedback, setSelectedFeedback] = useState(null);
  const navigate = useNavigate();
  
  useEffect(() => {
    apiCalls
      .getAllFeedback()
      .then((res) => {
        setFeedbacks(res.data.data);
      })
      .catch(console.error);
  }, []);
  
  /**
   * This method updating the read status of a feedback item and
   *  fetching the updated feedback count.
   *  @param {Object} feedback - The feedback item to be updated. 
   */
  const handleClick = (feedback) => {

    //Sets the modal state to true, indicating that the modal should be shown.
    setModalState(true);

    //Sets the selected feedback to the clicked feedback item.
    setSelectedFeedback(feedback);

    //Makes an API call to mark the feedback as read in the database.
    apiCalls.readFeedBack(feedback._id)
      .then(() => {

        // Maps over the existing feedbacks array to create a new array where the read status of the clicked
        // feedback item is updated. This is achieved by checking if the item._id matches the feedback._id and if so, 
        //creates a new object with the spread operator ({ ...item }) and sets the read property to 'yes'.
        const updatedFeedbacks = feedbacks.map((item) =>
          item._id === feedback._id ? { ...item, read: 'yes' } : item
        );

        //Updates the feedbacks state with the updated array of feedbacks.
        setFeedbacks(updatedFeedbacks);
  
        //Makes an API call to fetch the updated feedback count.
        apiCalls.getFeedbackCount()
          .then((count) => {
            //Updates the feedback count in the context.
            updateFeedbackCount(count.data.count);
          })
          .catch(console.error);
      })
      .catch(console.error);
  };
  
  /**
   * Handles the closing of the modal.
   */
  const handleCloseModal = () => {
    // Sets the modalState state to false, 
    //indicating that the modal should be closed.
    setModalState(false);

    //Sets the selectedFeedback state to null,
    // indicating that no feedback item is currently selected.
    setSelectedFeedback(null);

  };

  /**
   * Handles the deletion of a feedback item.
   * @param {string} id - The ID of the feedback item to be deleted. 
   */
  const handleDelete = (id) => {
    if(window.confirm('Are you sure you want to delete this feedback?')) {

        // Make an API call to delete the feedback item
        apiCalls.deleteFeedBack(id).then( () => {
        // Reload the page to reflect the updated feedback list
        window.location.reload();
        }).catch( (err) => {
            console.log(err);
        });
       // Show a success alert
      alert("Feedback deleted successfully!");

      //Show a success alert
      navigate("/feedback/list");

    }
  };

  return (
    <div>
      <NavBar/>
      <div className='container py-4'>
        <div className={styles.tableContainer}>
          <table>
            <thead>
              <tr>
              <th>Specimen</th>
                <th>Name</th>
                <th>Email</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
             
            {feedbacks.map((feedback, index) => (
  <tr key={feedbacks[feedbacks.length - index - 1].feedback._id} className={feedbacks[feedbacks.length - index - 1].read === 'yes' ? styles.readFeedback : styles.unreadFeedback}>
     <td>{feedbacks[feedbacks.length - index - 1].plantName}</td>
    <td>{feedbacks[feedbacks.length - index - 1].name}</td>
    <td>{feedbacks[feedbacks.length - index - 1].email}</td>
    <td>
      <button className={styles.viewButton} style={{ backgroundColor: '#1a3c34' }} onClick={() => handleClick(feedbacks[feedbacks.length - index - 1])}>
        View Feedback
      </button>
      <button className={styles.deleteButton} onClick={() => handleDelete(feedbacks[feedbacks.length - index - 1]._id)}>
        Delete
      </button>
    </td>
  </tr>
))}
            </tbody>
          </table>
        </div>
      </div>
      {modalState && (
        <div
        className={`${styles.modal} modal fade show`}
        tabIndex="-1"
        role="dialog"
        >
          <div className="modal-dialog modal-dialog-centered modal-lg" role="document" >
            <div className="modal-content" style={{backgroundColor: "#edf5e0"}}>
              <div className="modal-header" style={{backgroundColor: "#edf5e0"}}>
                <button
                  type="button"
                  className="btn-close"
                  data-dismiss="modal"
                  aria-label="Close"
                  onClick={handleCloseModal}
                />
              </div>
              <div className="modal-body d-flex justify-content-center align-items-center flex-column">
                <p>Author: {selectedFeedback.name}</p>
                <p>Email: {selectedFeedback.email}</p>
                <p>Feedback: {selectedFeedback.feedback}</p>
              </div>
            </div>
          </div>
        </div>
       
      )}
    </div>
        
   
  );
};
export default FeedbackList;