import SpecimenList from "./SpecimenList";
import SpecimenView from "./SpecimenView";
import LogInView from "./LogInView";
import QRGenerate from "./QRCode";
import UpdatePlantForm from "./UpdatePlantForm"


export {SpecimenList, SpecimenView, LogInView,QRGenerate ,UpdatePlantForm};
