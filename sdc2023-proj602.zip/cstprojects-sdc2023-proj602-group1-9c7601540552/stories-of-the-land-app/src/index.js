import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './app';
import { FeedbackProvider } from './context/FeedbackContext';
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <FeedbackProvider>
    <App />
  </FeedbackProvider>
  </React.StrictMode>
);

