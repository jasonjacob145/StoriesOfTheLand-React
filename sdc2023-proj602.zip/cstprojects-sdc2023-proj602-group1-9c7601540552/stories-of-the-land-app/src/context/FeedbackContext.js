import React, { createContext, useState } from 'react';

// Create a new context for managing feedback count
export const FeedbackContext = createContext();

// Create a provider component that wraps the application and provides the context
export const FeedbackProvider = ({ children }) => {

  // State to hold the feedback count  
  const [feedbackCount, setFeedbackCount] = useState(0);

  //Function to update the feedback count
  const updateFeedbackCount = (count) => {
    setFeedbackCount(count);
  };

  // Create a context value object with the feedback count and update function
  const contextValue = {
    feedbackCount,
    updateFeedbackCount,
  };

  return (
    //Render the provider component and pass the context value to its children
    <FeedbackContext.Provider value={contextValue}>
      {children}
    </FeedbackContext.Provider>
  );
};
